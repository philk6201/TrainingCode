let n = 5;
let string = "";

for (i = 0; i < n; i++) {

    for (j = 0; j < i; j++) {
        string += " ";
    }
    for (k = 0; k < (n - i) * 2 - 1; k++) {
        string += "*";
    }
    string += "\n";
}

for (i = 2; i <= n; i++) {

    for (j = n; j > i; j--) {
        string += " ";
    }

    for (k = 0; k < i * 2 - 1; k++) {
        string += "*";
    }
    string += "\n";
}
console.log(string);